package gui;

import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import model.ActionItemManager;

/**
 * <p>
 * Title: ConsoleScreen
 * </p>
 *
 * <p>
 * Description:  A manually generated action item screen for Della
 * </p>
 *
 * <p>
 * Copyright: Copyright � 2007
 * </p>
 *
 * @author Lynn Robert Carter
 * Many thanks to Harry Sameshima for his original work.
 * @version 1.00
 *  * @Co-author Vanshika Jain
 * @version Della00 Base Iteration 16-01-2021 Analyzing the code and understanding the flow of different classes using test script
 */
public class ConsoleScreen extends JPanel {
	//---------------------------------------------------------------------------------------------------------------------
	// Console Screen constants

	//---------------------------------------------------------------------------------------------------------------------
	// Console Screen attributes

	//---------------------------------------------------------------------------------------------------------------------
	// Console Screen GUI elements
	DefaultListModel dl=new DefaultListModel();
	JList actionlist= new JList(dl);
	JLabel consoleLabel = new JLabel();
	JLabel inclusion = new JLabel();
	JLabel copyrightLabel = new JLabel();
	JLabel nameLabel = new JLabel();
	JLabel selectedLabel = new JLabel();
	JLabel ActionItemscb = new JLabel();
	JTextField nameTextField = new JTextField();
	JLabel descriptionLabel = new JLabel();
	JLabel assign = new JLabel();
	JScrollPane descriptionScrollPane = new JScrollPane();
	JTextArea descriptionTextArea = new JTextArea();
	JLabel resolutionLabel = new JLabel();
	JScrollPane resolutionScrollPane = new JScrollPane();
	JTextArea resolutionTextArea = new JTextArea();
	//---------------------------------------------------------------------------------------------------------------------
	JComboBox sortingdirectioncb = new JComboBox();
	JComboBox firstsfcb = new JComboBox();
	JComboBox secondsfcb = new JComboBox();
	JComboBox inclusioncb = new JComboBox();
	JLabel datesLabel = new JLabel();
	JLabel assignlb = new JLabel();
	JLabel assigntlb = new JLabel();
	JLabel assignt = new JLabel();
	JLabel sortingdirection = new JLabel();
	JLabel firstsf = new JLabel();
	JLabel secondsf = new JLabel();
	JLabel dueValueLabel = new JLabel();
	JLabel statusValueLabel = new JLabel();
	JLabel creationLabel = new JLabel();
	JLabel creationValueLabel = new JLabel();
	JLabel dueDateLabel = new JLabel();
	JTextField dueDateTextField = new JTextField();
	JLabel formatLabel = new JLabel();
	JLabel actionItemLabel2 = new JLabel();
	JLabel statusLabel = new JLabel();
	JComboBox statusComboBox = new JComboBox(ActionItemManager.statusStrings);

	File file=new File("file.txt");
	ArrayList al=new ArrayList();
	ArrayList alist=new ArrayList();
	/**
	 * The ConsoleScreen class constructor.
	 * 
	 */
	public ConsoleScreen() {
		// Set up all of the Graphical User Interface elements and position them on the screen
		guiInit();
	}

	/**
	 * Initialize each graphic element, position it on the screen, and add it to the loayout.
	 * 
	 */
	private void guiInit() {
		this.setLayout(null);
		consoleLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 14));
		consoleLabel.setBorder(BorderFactory.createEtchedBorder());
		consoleLabel.setHorizontalAlignment(SwingConstants.CENTER);
		consoleLabel.setText("Console");
		consoleLabel.setBounds(new Rectangle(0, 0, 657, 20));

		copyrightLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 10));
		copyrightLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		copyrightLabel.setText("Copyright � Vanshika Jain");
		copyrightLabel.setBounds(new Rectangle(0, 398, 605, 15));

		//label action items
				ActionItemscb.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
				ActionItemscb.setText("Action Items:");
				ActionItemscb.setBounds(new Rectangle(6, 20, 123, 15));
				
		selectedLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		selectedLabel.setText("Selected Action Item:");
		selectedLabel.setBounds(new Rectangle(6, 145, 123, 15));
		nameLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		nameLabel.setText("Name:");
		nameLabel.setBounds(new Rectangle(7, 165, 42, 15));
		nameTextField.setText("");
		nameTextField.setBounds(new Rectangle(46, 165, 390, 22));
		nameTextField.setEditable(false);
		descriptionLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		descriptionLabel.setText("Description:");
		descriptionLabel.setBounds(new Rectangle(6, 190, 69, 15));
		descriptionScrollPane.setBounds(new Rectangle(7, 210, 430, 75));
		descriptionScrollPane.getViewport().add(descriptionTextArea);
		descriptionTextArea.setText("");
		descriptionTextArea.setEditable(false);
		resolutionLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		resolutionLabel.setText("Resolution:");
		resolutionLabel.setBounds(new Rectangle(6, 295, 73, 15));
		resolutionScrollPane.setBounds(new Rectangle(7, 315, 430, 75));
		resolutionScrollPane.getViewport().add(resolutionTextArea);
		resolutionTextArea.setToolTipText("");
		resolutionTextArea.setText("");
		resolutionTextArea.setEditable(false);
		
		datesLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		datesLabel.setText("Dates");
		datesLabel.setBounds(new Rectangle(450, 230, 34, 16));

		creationLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		creationLabel.setText("Creation:");
		creationLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		creationLabel.setBounds(new Rectangle(469, 250, 51, 16));
		creationValueLabel.setText("");
		creationValueLabel.setBounds(new Rectangle(528, 250, 85, 16));

		dueDateLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		dueDateLabel.setText("Due:");
		dueDateLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		dueDateLabel.setBounds(new Rectangle(469, 270, 51, 16));
		dueValueLabel.setText("");
		dueValueLabel.setBounds(new Rectangle(528, 270, 85, 16));
		
		actionItemLabel2.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		actionItemLabel2.setText("Action Item");
		actionItemLabel2.setBounds(new Rectangle(450, 290, 67, 15));

		statusLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		statusLabel.setText("Status:");
		statusLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		statusLabel.setBounds(new Rectangle(469, 310, 51, 16));
		statusValueLabel.setText("");
		statusValueLabel.setBounds(new Rectangle(528, 310, 85, 16));
		
		assign.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		assign.setText("Assigned to Member:");
		assign.setHorizontalAlignment(SwingConstants.RIGHT);
		assign.setBounds(new Rectangle(425, 329, 150, 16));
		assignlb.setBounds(new Rectangle(469, 340, 150, 25));
		
		assignt.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		assignt.setText("Assigned to Team:");
		assignt.setHorizontalAlignment(SwingConstants.RIGHT);
		assignt.setBounds(new Rectangle(405, 360, 150, 16));
		assigntlb.setBounds(new Rectangle(469, 370, 150, 25));
		
		inclusion.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		inclusion.setText("Inclusion Factor");
		inclusion.setBounds(new Rectangle(489, 180, 123, 15));
		
		inclusioncb.setBounds(new Rectangle(489, 200, 130, 25));
		inclusioncb.addItem("Open Action Items");
		inclusioncb.addItem("Closed Action Items");
		inclusioncb.addItemListener(new ItemListener() {

			public void itemStateChanged(ItemEvent e) {
				
				JComboBox inclusioncb=(JComboBox)e.getSource();
				Object item=e.getItem();
				int select=inclusioncb.getSelectedIndex();
				if(e.getStateChange()==ItemEvent.SELECTED) {
				
					switch(select) {
					case 0:
						try {
							BufferedReader br=new BufferedReader(new FileReader(file));
							String st;
							try {alist.clear();
								while((st=br.readLine())!=null) {
									String a[]=st.split(",");
									for(int i=0;i<a.length;i++) {
									if(a[i].contains("Open")) {
									alist.add(a[0]);
									}
									}
								}
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						}
						catch (FileNotFoundException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						dl.removeAllElements();
						String[] arr= (String[]) alist.toArray(new String[] {});
						Arrays.sort(arr,0,arr.length);
						for(int i=0;i<arr.length;i++) {
							dl.addElement(arr[i]);
						}
						break;
						
					case 1:
						try {
							BufferedReader br=new BufferedReader(new FileReader(file));
							String st;
							try {alist.clear();
								while((st=br.readLine())!=null) {
									String a[]=st.split(",");
									for(int i=0;i<a.length;i++) {
									if(a[i].contains("Closed")) {
									alist.add(a[0]);
									}
									}
								}
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						}
						catch (FileNotFoundException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						dl.removeAllElements();
						String[] array= (String[]) alist.toArray(new String[] {});
						Arrays.sort(array,0,array.length);
						for(int i=0;i<array.length;i++) {
							dl.addElement(array[i]);
						}
						break;
					}
			}}
			
		});
		
		
		//label sorting direction
		sortingdirection.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		sortingdirection.setText("Sorting Direction:");
		sortingdirection.setBounds(new Rectangle(489, 25, 123, 15));
		sortingdirectioncb.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				JComboBox sortingdirectioncb=(JComboBox)e.getSource();
				Object item=e.getItem();
				
				int selection=sortingdirectioncb.getSelectedIndex();
				switch(selection) {
				case 0: lts();
				
					break;
				case 1: stl();
					break;
				}
			}
		});
		//label first sorting factor
		firstsf.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		firstsf.setText("First Sorting Factor:");
		firstsf.setBounds(new Rectangle(489, 75, 240, 15));
		
		//label second sorting factor
		secondsf.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		secondsf.setText("Second Sorting Factor:");
		secondsf.setBounds(new Rectangle(489, 125, 243, 15));
		
		sortingdirectioncb.setBounds(new Rectangle(489, 45, 110, 25));
		sortingdirectioncb.addItem("Large to Small");
		sortingdirectioncb.addItem("Small to Large");
		
		firstsfcb.setBounds(new Rectangle(489, 95, 110, 25));
		firstsfcb.addItem("None");
		firstsfcb.addItem("Creation Date");
		firstsfcb.addItem("Due Date");
		firstsfcb.addItem("Assigned Member");
		firstsfcb.addItem("Assigned Team");
		firstsfcb.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				int selection=firstsfcb.getSelectedIndex();
				JComboBox firstsfcb=(JComboBox)e.getSource();
				Object item=e.getItem();
				switch(selection) {
				case 0: 
					if(secondsfcb.getSelectedIndex()==0) {
					if(sortingdirectioncb.getSelectedIndex()==0) {
						lts();
					}
					else if(sortingdirectioncb.getSelectedIndex()==1) {
						stl();
					}
					}
					
					if(secondsfcb.getSelectedIndex()==1) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							duels();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							duesl();
						}
						}
					
					if(secondsfcb.getSelectedIndex()==2) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							createls();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							createsl();
						}
						}
					break;
				case 1: 
					if(secondsfcb.getSelectedIndex()==0) {
					if(sortingdirectioncb.getSelectedIndex()==0) {
						createls();
					}
					else if(sortingdirectioncb.getSelectedIndex()==1) {
						createsl();
					}
					}
					
					if(secondsfcb.getSelectedIndex()==1) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							duecreatels();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							duecreatesl();
						}
					}
					if(secondsfcb.getSelectedIndex()==3) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							assigncl();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							assigncs();
						}
						}
					break;
					case 2:
						if(secondsfcb.getSelectedIndex()==0) {
							if(sortingdirectioncb.getSelectedIndex()==0) {
								duels();
							}
							else if(sortingdirectioncb.getSelectedIndex()==1) {
								duesl();
							}
							}
						if(secondsfcb.getSelectedIndex()==2) {
							if(sortingdirectioncb.getSelectedIndex()==0) {
								duecreatels();	
							}
							else if(sortingdirectioncb.getSelectedIndex()==1) {
								duecreatesl();
							}
							}
						if(secondsfcb.getSelectedIndex()==3) {
							if(sortingdirectioncb.getSelectedIndex()==0) {
								assigndl();
							}
							else if(sortingdirectioncb.getSelectedIndex()==1) {
								assignds();
							}
							}
						break;
					case 3:
						if(secondsfcb.getSelectedIndex()==0) {
							if(sortingdirectioncb.getSelectedIndex()==0) {
								assignls();
							}
							else if(sortingdirectioncb.getSelectedIndex()==1) {
								assignsl();
							}
							}
						
						if(secondsfcb.getSelectedIndex()==1) {
							if(sortingdirectioncb.getSelectedIndex()==0) {
								assigndl();
							}
							else if(sortingdirectioncb.getSelectedIndex()==1) {
								assignds();
							}
							}
						
						if(secondsfcb.getSelectedIndex()==2) {
							if(sortingdirectioncb.getSelectedIndex()==0) {
								assigncl();
							}
							else if(sortingdirectioncb.getSelectedIndex()==1) {
								assigncs();
							}
							}
						if(secondsfcb.getSelectedIndex()==4) {
							if(sortingdirectioncb.getSelectedIndex()==0) {
								assigntcdl();
							}
							else if(sortingdirectioncb.getSelectedIndex()==1) {
								assigntcds();
							}
							}
						break;
					case 4:
						if(secondsfcb.getSelectedIndex()==0) {
							if(sortingdirectioncb.getSelectedIndex()==0) {
								assigntls();
							}
							else if(sortingdirectioncb.getSelectedIndex()==1) {
								assigntsl();
							}
							}
						
						if(secondsfcb.getSelectedIndex()==1) {
							if(sortingdirectioncb.getSelectedIndex()==0) {
								assigntdl();
							}
							else if(sortingdirectioncb.getSelectedIndex()==1) {
								assigntds();
							}
							}
						
						if(secondsfcb.getSelectedIndex()==2) {
							if(sortingdirectioncb.getSelectedIndex()==0) {
								assigntcl();
							}
							else if(sortingdirectioncb.getSelectedIndex()==1) {
								assigntcs();
							}
							}
						if(secondsfcb.getSelectedIndex()==3) {
							if(sortingdirectioncb.getSelectedIndex()==0) {
								assigntcdl();
							}
							else if(sortingdirectioncb.getSelectedIndex()==1) {
								assigntcds();
							}
							}
						
						break;
					}
				}
		});	
		secondsfcb.setBounds(new Rectangle(489, 145, 110, 25));
		secondsfcb.addItem("None");
		secondsfcb.addItem("Due Date");
		secondsfcb.addItem("Creation Date");
		secondsfcb.addItem("Assigned Member");
		secondsfcb.addItem("Assigned Team");
		secondsfcb.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				int selection=secondsfcb.getSelectedIndex();
				JComboBox secondsfcb=(JComboBox)e.getSource();
				Object item=e.getItem();
				switch(selection) {
				case 0: 
					if(firstsfcb.getSelectedIndex()==0) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							lts();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							stl();
						}
						}
					if(firstsfcb.getSelectedIndex()==1) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							createls();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							createsl();
						}
						}
					if(firstsfcb.getSelectedIndex()==2) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							duels();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							duesl();
						}
						}
						break;
				case 1:
					if(firstsfcb.getSelectedIndex()==0) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							duels();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
						duesl();
						}
						}
					if(firstsfcb.getSelectedIndex()==1) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							duecreatels();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							duecreatesl();
						}
						}
					if(firstsfcb.getSelectedIndex()==3) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							assigndl();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							assignds();
						}
						}
					break;
				case 2:
					if(firstsfcb.getSelectedIndex()==0) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							createls();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							createsl();
						}
						}
					if(firstsfcb.getSelectedIndex()==2) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							duecreatels();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							duecreatesl();
						}
						}
					if(firstsfcb.getSelectedIndex()==3) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							assigncl();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							assigncs();
						}
						}
					break;
					
				case 3:
					if(firstsfcb.getSelectedIndex()==0) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							assignls();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							assignsl();
						}
						}
					if(firstsfcb.getSelectedIndex()==2) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							assigndl();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							assignds();
						}
						}
					
					if(firstsfcb.getSelectedIndex()==1) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							assigncl();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							assigncs();
						}
						}
					if(firstsfcb.getSelectedIndex()==4) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							assigntcdl();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							assigntcds();
						}
						}
					break;
				case 4:
					if(firstsfcb.getSelectedIndex()==0) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							assigntls();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							assigntsl();
						}
						}
					
					if(firstsfcb.getSelectedIndex()==1) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							assigntdl();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							assigntds();
						}
						}
					
					if(firstsfcb.getSelectedIndex()==2) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							assigntcl();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							assigntcs();
						}
						}
					if(firstsfcb.getSelectedIndex()==3) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							assigntcdl();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							assigntcds();
						}
						}
					
					break;
				}
			}
		});
		actionlist.setBounds(10,40,428,100);
		
		actionlist.addMouseListener(new MouseAdapter() {
	         public void mouseClicked(MouseEvent me) {
	            if (me.getClickCount() == 1) {
	               JList target = (JList)me.getSource();
	               int index = target.locationToIndex(me.getPoint());
	               if (index >= 0) {
	                  Object item = target.getModel().getElementAt(index);
	                  Scanner sc = null;
					    try {
					      sc = new Scanner(file);

					      // Check if there is another line of input
					      while(sc.hasNextLine()){
					        String str = sc.nextLine();
					        String a[]=item.toString().split(" ");
					        String b="";
					        for(int i=0;i<a.length;i++) {
					        	if(a[i].contains(":")) {
					        		continue;
					        	}
					        	b=b+a[i];
					        }
					        if(str.contains(b)) {
					        // parse each line using delimiter
					      Scanner linescanner=new Scanner(str);
					      String name=null,des=null,res=null,due=null,creation=null,status=null,assign=null,team=null;
					      linescanner.useDelimiter(",");
					      while(linescanner.hasNext()) {
					    	  name=linescanner.next();
					    	  des=linescanner.next();
					    	  res=linescanner.next();
					    	  due=linescanner.next();
					    	  creation=linescanner.next();
					    	  status=linescanner.next();
					    	  assign=linescanner.next();
					    	  team=linescanner.next();
					    	  nameTextField.setText(name); 
					    	  descriptionTextArea.setText(des);
					    	  resolutionTextArea.setText(res);
					    	  dueValueLabel.setText(due);
					    	  creationValueLabel.setText(creation);
					    	  statusValueLabel.setText(status);
					    	  assignlb.setText(assign);
					    	  assigntlb.setText(team);
					    	  
					      }
					      linescanner.close();
					        }
					      }
					      
					    } catch (IOException  exp) {
					      // TODO Auto-generated catch block
					      exp.printStackTrace();
					    }finally{
					      if(sc != null)
					        sc.close();
					    }	  	
							
				}
	               }
	            }
	         
	      });
		
		this.add(consoleLabel);
		this.add(copyrightLabel);
		this.add(selectedLabel);
		this.add(ActionItemscb);
		this.add(nameLabel);
		this.add(nameTextField);
		this.add(descriptionLabel);
		this.add(resolutionLabel);
		this.add(descriptionScrollPane);
		this.add(resolutionScrollPane);
		this.add(creationLabel);
		this.add(creationValueLabel);
		this.add(dueDateLabel);
		this.add(datesLabel);
		this.add(actionItemLabel2);
		this.add(inclusion);
		this.add(inclusioncb);
		this.add(statusLabel);
		this.add(dueValueLabel);
		this.add(statusValueLabel);
		this.add(sortingdirection);
		this.add(firstsf);
		this.add(secondsf);
		this.add(sortingdirectioncb);
		this.add(firstsfcb);
		this.add(secondsfcb);
		this.add(actionlist);
		this.add(assign);
		this.add(assignlb);
		this.add(assignt);
		this.add(assigntlb);
	}
	public void lts() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		dl.removeAllElements();
		String[] ar= (String[]) al.toArray(new String[] {});
		Arrays.sort(ar,0,ar.length);
		for(int k=ar.length-1;k>=0;k--) {
			dl.addElement(ar[k]);
		}
	}
	
	public void stl() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		dl.removeAllElements();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=0;i<arr.length;i++) {
			dl.addElement(arr[i]);
		}
	}
	public void assigntcdl() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[7]+": "+a[6]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		dl.removeAllElements();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=arr.length-1;i>=0;i--) {
			dl.addElement(arr[i]);
		}	
	}
	public void assigntcds() {
		  try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[7]+": "+a[6]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		dl.removeAllElements();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=0;i<arr.length;i++) {
			dl.addElement(arr[i]);
		}
		}
	
	public  void duecreatesl() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[3]+": "+a[4]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		dl.removeAllElements();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=0;i<arr.length;i++) {
			dl.addElement(arr[i]);
		}
	}
	
	public void duecreatels() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[3]+": "+a[4]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}dl.removeAllElements();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=arr.length-1;i>=0;i--) {
			dl.addElement(arr[i]);
		}	
	}
	
	public void createls() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[4]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		dl.removeAllElements();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=arr.length-1;i>=0;i--) {
			dl.addElement(arr[i]);
		}	
	}
	
	public void createsl() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[4]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		dl.removeAllElements();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=0;i<arr.length;i++) {
			dl.addElement(arr[i]);
		}
	}
	
	public void duesl() {
	  try {
		BufferedReader br=new BufferedReader(new FileReader(file));
		String st;
		try {al.clear();
			while((st=br.readLine())!=null) {
				String a[]=st.split(",");
				al.add(a[3]+": "+a[0]);
			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	catch (FileNotFoundException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	  dl.removeAllElements();
	String[] arr= (String[]) al.toArray(new String[] {});
	Arrays.sort(arr,0,arr.length);
	for(int i=0;i<arr.length;i++) {
		dl.addElement(arr[i]);
	}
	}
	
	public void duels() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[3]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		dl.removeAllElements();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=arr.length-1;i>=0;i--) {
			dl.addElement(arr[i]);
		}	
	}
	
	
	public void assignsl() {
		  try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[6]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		dl.removeAllElements();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=0;i<arr.length;i++) {
			dl.addElement(arr[i]);
		}
		}
	
	public void assignls() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[6]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		dl.removeAllElements();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=arr.length-1;i>=0;i--) {
			dl.addElement(arr[i]);
		}	
	}
	
	public void assigncl() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[6]+": "+a[4]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		dl.removeAllElements();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=arr.length-1;i>=0;i--) {
			dl.addElement(arr[i]);
		}	
	}
	
	public void assigndl() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[6]+": "+a[3]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		dl.removeAllElements();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=arr.length-1;i>=0;i--) {
			dl.addElement(arr[i]);
		}	
	}
	
	public void assigncs() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[6]+": "+a[3]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		dl.removeAllElements();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=arr.length-1;i>=0;i--) {
			dl.addElement(arr[i]);
		}
	}
	
	public void assignds() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[6]+": "+a[3]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		dl.removeAllElements();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=0;i<arr.length;i++) {
			dl.addElement(arr[i]);
		}
	}
	public void assigntls() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[7]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		dl.removeAllElements();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=arr.length-1;i>=0;i--) {
			dl.addElement(arr[i]);
		}	
	}
	public void assigntdl() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[7]+": "+a[3]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		dl.removeAllElements();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=arr.length-1;i>=0;i--) {
			dl.addElement(arr[i]);
		}	
	}
	public void assigntds() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[7]+": "+a[3]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		dl.removeAllElements();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=0;i<arr.length;i++) {
			dl.addElement(arr[i]);
		}
	}
	public void assigntcs() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[7]+": "+a[3]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		dl.removeAllElements();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=arr.length-1;i>=0;i--) {
			dl.addElement(arr[i]);
		}
	}
	public void assigntcl() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[7]+": "+a[4]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		dl.removeAllElements();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=arr.length-1;i>=0;i--) {
			dl.addElement(arr[i]);
		}	
	}
	public void assigntsl() {
		  try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[7]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		dl.removeAllElements();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=0;i<arr.length;i++) {
			dl.addElement(arr[i]);
		}
		}
	}
	

