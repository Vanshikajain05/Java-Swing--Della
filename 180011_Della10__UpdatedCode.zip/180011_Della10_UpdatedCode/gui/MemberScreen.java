package gui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import javax.swing.*;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/**
 * <p>
 * Title: MemberScreen
 * </p>
 *
 * <p>
 * Description: The Della Member Screen code
 * </p>
 *
 * <p>
 * Copyright: Copyright � 2007
 * </p>
 *
 * @author Lynn Robert Carter
 * @version 1.00
 *  * @Co-author Vanshika Jain
 * @version Della00 Base Iteration 16-01-2021 Analyzing the code and understanding the flow of different classes using test script
 * Many thanks to Harry Sameshima for his original work.
*/
public class MemberScreen extends JPanel {
	//---------------------------------------------------------------------------------------------------------------------
	// Member Screen constants


	//---------------------------------------------------------------------------------------------------------------------
	// Member Screen attributes


	//---------------------------------------------------------------------------------------------------------------------
	// Member Screen GUI elements
	ArrayList al=new ArrayList();
	ArrayList aln=new ArrayList();
	JLabel memberLabel = new JLabel();
	DefaultListModel dl=new DefaultListModel();
	JList memberlist= new JList(dl);
	
	DefaultListModel dl2=new DefaultListModel();
	JList availableteamlist= new JList(dl2);

	DefaultListModel dl3=new DefaultListModel();
	JList currentteamlist= new JList(dl3);
	JLabel someonenew = new JLabel();
	JLabel elabel = new JLabel();
	JLabel alabel = new JLabel();
	JLabel alabelvalue = new JLabel();
	JLabel blabel = new JLabel();
	JLabel blabelvalue = new JLabel();
	JLabel info2 = new JLabel();
	JLabel individual = new JLabel();
	JTextField nameTextField = new JTextField();
	JButton add = new JButton();
	ActionListener addlistener = new ActionListener() {
		public void actionPerformed(ActionEvent ae) { add(); }
	};
	
	JButton addaff = new JButton();
	ActionListener addafflistener = new ActionListener() {
		public void actionPerformed(ActionEvent ae) {  }
	};
	JButton raff = new JButton();
	ActionListener rafflistener = new ActionListener() {
		public void actionPerformed(ActionEvent ae) {  }
	};
	JButton remove = new JButton();
	ActionListener removelistener = new ActionListener() {
		public void actionPerformed(ActionEvent ae) { try {
			remove();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} }
	};
	
	JLabel info = new JLabel();
	JLabel info3 = new JLabel();
	JLabel info1 = new JLabel();
	//---------------------------------------------------------------------------------------------------------------------

	/**
	 * The MemberScreen class constructor.
	 * 
	 */
	public MemberScreen() {
		// Set up all of the Graphical User Interface elements and place them on the screen
		guiInit();
		load();
	}

	/**
	 * Initialize each graphic element, position it on the screen, and add it to the layout.
	 * 
	 */
	private void guiInit() {
		this.setLayout(null);
		memberLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 14));
		memberLabel.setBorder(BorderFactory.createEtchedBorder());
		memberLabel.setHorizontalAlignment(SwingConstants.CENTER);
		memberLabel.setText("Members");
		memberLabel.setBounds(new Rectangle(2, 10, 657, 20));
		
		someonenew.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		someonenew.setText("Name of someone new(Last, First MIddle)");
		someonenew.setBounds(new Rectangle(6, 35, 283, 15));
		
		individual.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		individual.setText("Individuals known by Della");
		individual.setBounds(new Rectangle(410, 35, 283, 15));
		
		nameTextField.setText("");
		nameTextField.setBounds(new Rectangle(6, 65, 160, 22));
		
		elabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		elabel.setText("");
		elabel.setBounds(new Rectangle(70, 163, 283, 15));
		elabel.setForeground(Color.red);	
		add.setFont(new Font("Dialog", Font.BOLD, 13));
		add.setBounds(new Rectangle(200, 85, 160, 32));
		add.setText("Add to List->");
		add.addActionListener(addlistener);
		
	
		addaff.setFont(new Font("Dialog", Font.BOLD, 13));
		addaff.setBounds(new Rectangle(200, 335, 160, 32));
		addaff.setText("Add affiliation->");
		add.addActionListener(addafflistener);
		
		raff.setFont(new Font("Dialog", Font.BOLD, 13));
		raff.setBounds(new Rectangle(200, 385, 170, 32));
		raff.setText("<-Remove affiliation");
		raff.addActionListener(rafflistener);
		info.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		info.setText("<html>To add a name to the list:<br>1. Click on the box above.<br>2. Type the name.<br>3. Click on 'Add to List'option.</html>");
		info.setBounds(new Rectangle(8, 85, 283, 80));
		
		info1.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		info1.setText("<html>To remove a name from the list:<br>1. Click on the name to remove.<br>2. Click on 'Remove from List'option.</html>");
		info1.setBounds(new Rectangle(8, 155, 283, 80));
		
		info2.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		info2.setText("<html>To add a team affliation for an individual:<br>1. Click on the name to of the individual above.<br>2. Click on a team name in the list below<br>3. Click on add affiliation button.</html>");
		info2.setBounds(new Rectangle(8, 225, 283, 80));
		
		info3.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		info3.setText("<html>To remove a team affliation for an individual:<br>1. Click on the name to of the individual above.<br>2. Click on a team name in the list below<br>3. Click on remove affiliation button.</html>");
		info3.setBounds(new Rectangle(348, 225, 283, 80));
		
		alabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		alabel.setText("Available teams for: ");
		alabel.setBounds(new Rectangle(10, 305, 150, 15));
		
		alabelvalue.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		alabelvalue.setText("");
		alabelvalue.setBounds(new Rectangle(150, 305, 170, 15));
		
		blabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		blabel.setText("Current teams for: ");
		blabel.setBounds(new Rectangle(388, 305, 120, 15));
		
		blabelvalue.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		blabelvalue.setText("");
		blabelvalue.setBounds(new Rectangle(498, 305, 170, 15));
		
		availableteamlist.setBounds(8,325,150,105);
		
		currentteamlist.setBounds(428,325,150,105);
		remove.setFont(new Font("Dialog", Font.BOLD, 13));
		remove.setBounds(new Rectangle(200, 125, 160, 32));
		remove.setText("<-Remove from List");
		remove.addActionListener(removelistener);
		
		memberlist.setBounds(410,55,150,130);
		memberlist.addMouseListener(new MouseAdapter() {
	         public void mouseClicked(MouseEvent me) {
	            if (me.getClickCount() == 1) {
	               JList target = (JList)me.getSource();
	               int index = target.locationToIndex(me.getPoint());
	               if (index >= 0) {
	                  Object item = target.getModel().getElementAt(index);
	                  
	                  try {
	                	  File action=new File("file.txt");
	          			BufferedReader br=new BufferedReader(new FileReader(action));
	          			String st;
	          			try {aln.clear();
	          				while((st=br.readLine())!=null) {
	          					String a[]=st.split(",");
	          					
	          					for(int i=0;i<a.length;i++) {
	          					if(a[i].contains(item.toString())) {
	          					aln.add(a[7]);
	          					blabelvalue.setText(a[6]);
	          					alabelvalue.setText(a[6]);
	          					}
	          				}
	          				}
	          				
	          			} catch (IOException e) {
	          				// TODO Auto-generated catch block
	          				e.printStackTrace();
	          			}
	          		}
	          		
	          		catch (FileNotFoundException e) {
	          			// TODO Auto-generated catch block
	          			e.printStackTrace();
	          		}
                     dl3.removeAllElements();
	          		String[] ar= (String[]) aln.toArray(new String[] {});
	          		//Arrays.sort(ar,0,ar.length);
	          		for(int i=0;i<ar.length;i++) {
	          			dl3.addElement(ar[i]);
	          			
	          		}
	               }
	            }
	         }
					
	      });
		//dl.setSize(100);
		//----------------------------------------------------------------------------
		// Add the objects to the layout
		this.add(memberLabel);
		this.add(someonenew);
		this.add(blabelvalue);
		this.add(blabel);
		this.add(nameTextField);
		this.add(add);
		this.add(remove);
		this.add(info);
		this.add(individual);
		this.add(availableteamlist);
		this.add(info1);
		this.add(info2);
		this.add(currentteamlist);
		this.add(memberlist);
		this.add(elabel);
		this.add(alabel);
		this.add(alabelvalue);
		this.add(addaff);
		this.add(raff);
		this.add(info3);
		
	}
	File file=new File("Members.txt");
	
	public void add() {
		
if(!(file.exists())) {
	try {
		file.createNewFile();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

		if(nameTextField.getText().isEmpty()) {
			
			elabel.setText("Fill the member name in the required field");
		}
		else  {
     
       try {
		 BufferedWriter writer=new BufferedWriter(new FileWriter(file,true));
		 String s=nameTextField.getText().toString();
		 dl.addElement(s);
		 writer.write(s);
		   writer.write("\n");
	     writer.close();
     } 
       catch (IOException e1) {
	// TODO Auto-generated catch block
	e1.printStackTrace();
          }
       elabel.setText("");
		}
	nameTextField.setText("");
	for(int i=0;i<al.size();i++) {
		if(nameTextField.getText().equalsIgnoreCase((String) dl.getElementAt(i))) {
			elabel.setText("Duplicate Entry!");
			dl.remove(i);
		
		}
		}
}
	public void remove() throws IOException {
		int select=memberlist.getSelectedIndex();
		dl.remove(select);
		if(dl.isEmpty()) {
			elabel.setText("List is empty");
		}
		
	                  try {
	                	  File action=new File("Members.txt");
	          			BufferedReader br=new BufferedReader(new FileReader(action));
	          			
	          			String st;
	          			try {al.clear();
	          				while((st=br.readLine())!=null) {
	          					BufferedWriter bw=new BufferedWriter(new FileWriter(action));
	          					if(st.equals(memberlist.getSelectedValue())) {
	          						al.remove(st);
	          						dl3.removeAllElements();
	          				        alabelvalue.setText("");
	          				        blabelvalue.setText("");
	          					}
	          					al.add(st);
	          				bw.write(st);
	          				bw.write("\n");
	          				bw.close();
	          				}
	          				
	          				br.close();
	          			} catch (IOException e) {
	          				// TODO Auto-generated catch block
	          				e.printStackTrace();
	          			}
	                  }
	          		
	          		catch (FileNotFoundException e) {
	          			// TODO Auto-generated catch block
	          			e.printStackTrace();
	          		}
	                  dl.removeAllElements();
	          		String[] ar= (String[]) al.toArray(new String[] {});
	          		//Arrays.sort(ar,0,ar.length);
	          		for(int i=0;i<ar.length;i++) {
	          			dl.addElement(ar[i]);
	          			
	          		}
	               
	    }
		
	private void load() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					al.add(st);
				}
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String[] ar= (String[]) al.toArray(new String[] {});
		//Arrays.sort(ar,0,ar.length);
		for(int i=0;i<ar.length;i++) {
			dl.addElement(ar[i]);
			
		}
	}
}
