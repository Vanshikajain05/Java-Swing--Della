package gui;

import java.awt.*;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import control.*;
import java.util.Arrays;
import model.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

/**
 * <p>
 * Title: ActionItemScreen
 * </p>
 * 
 * <p>
 * Description: A manually generated Action Item Screen for Della
 * </p>
 * 
 * <p>
 * Copyright: Copyright � 2007
 * </p>
 * 
 * @author Lynn Robert Carter
 * @version 1.00
 *  * @Co-author Vanshika Jain
 * @version Della00 Base Iteration 16-01-2021 Analyzing the code and understanding the flow of different classes using test script
 * Many thanks to Harry Sameshima for his original work.
 */
public class ActionItemScreen extends JPanel {
	//---------------------------------------------------------------------------------------------------------------------
	// Action Item Screen constants

	public static final int noItemSelected = -1;

	//---------------------------------------------------------------------------------------------------------------------
	// Action Item Screen attributes
	ArrayList alist=new ArrayList();
	private boolean updatingGUI = false;
	private Controller theController = null;
	private ActionItemManager aiM = null;
	private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

	//---------------------------------------------------------------------------------------------------------------------
	// Action Item Screen GUI elements
	JLabel actionItemLabel = new JLabel();
	JLabel sortingdirection = new JLabel();
	
	JLabel inclusion = new JLabel();
	JLabel firstsf = new JLabel();
	JLabel secondsf = new JLabel();
	JLabel selectedLabel = new JLabel();
	JLabel nameLabel = new JLabel();
	JLabel assign = new JLabel();
	JLabel assignt = new JLabel();
	//declare label action items
	JLabel ActionItemscb = new JLabel();
	
	//declare label select action
	JLabel selectaction = new JLabel();
	JTextField nameTextField = new JTextField();
	JLabel descriptionLabel = new JLabel();
	JScrollPane descriptionScrollPane = new JScrollPane();
	JTextArea descriptionTextArea = new JTextArea();
	JLabel resolutionLabel = new JLabel();
	JScrollPane resolutionScrollPane = new JScrollPane();
	JTextArea resolutionTextArea = new JTextArea();

	// Unsaved updated fields
	DocumentListener aiChangeListener = new DocumentListener() {
		public void changedUpdate(DocumentEvent de){ checkForUnsavedUpdates(); }
		public void insertUpdate(DocumentEvent de){ checkForUnsavedUpdates(); }
		public void removeUpdate(DocumentEvent de){ checkForUnsavedUpdates(); }
	};
	JLabel unsavedChangesLabel = new JLabel();

	JLabel datesLabel = new JLabel();
	JLabel creationLabel = new JLabel();
	JLabel creationValueLabel = new JLabel();
	JLabel dueDateLabel = new JLabel();
	JTextField dueDateTextField = new JTextField();
	JLabel formatLabel = new JLabel();
	JLabel actionItemLabel2 = new JLabel();
	JLabel statusLabel = new JLabel();
	JComboBox statusComboBox = new JComboBox(ActionItemManager.statusStrings);
	
	ArrayList al=new ArrayList();
	
	
//declare cbox
	JComboBox actioncb = new JComboBox();
	JComboBox sortingdirectioncb = new JComboBox();
	JComboBox inclusioncb = new JComboBox();
	JComboBox firstsfcb = new JComboBox();
	JComboBox secondsfcb = new JComboBox();
	JComboBox assigncb = new JComboBox();
	JComboBox assigntcb = new JComboBox();
	ActionListener createnewitem = new ActionListener() {
		public void actionPerformed(ActionEvent ae) { createnewitem(ae); }
	};
	ActionListener deletethisactionitem = new ActionListener() {
		public void actionPerformed(ActionEvent ae) {  }
	};
	ActionListener statusSelectorActionListner = new ActionListener() {
		public void actionPerformed(ActionEvent ae) { checkForUnsavedUpdates(); }
	};

	// Action Buttons
	JButton updateButton = new JButton();
	ActionListener updateButtonActionListner = new ActionListener() {
		public void actionPerformed(ActionEvent ae) { updateActionItem(ae); }
	};
	JButton clearButton = new JButton();
	ActionListener clearButtonActionListner = new ActionListener() {
		public void actionPerformed(ActionEvent ae) { clearActionItemForm(ae); }
	};
	
	//button create new action item
	JButton createnewactionitem = new JButton();
	JButton deleteactionitem = new JButton();
	ActionListener delButtonActionListner = new ActionListener() {
		public void actionPerformed(ActionEvent ae) { deleteai(); }
	};
	//---------------------------------------------------------------------------------------------------------------------
   ArrayList assignmember=new ArrayList();
   ArrayList assignteam=new ArrayList();
	/**
	 * The ActionItemScreen class constructor.
	 * 
	 */
	public ActionItemScreen() {
		// Use a modified singleton pattern to access the application's state
		theController = Controller.getInstance();
		aiM = theController.getActionItemManager();

		// Set up all of the Graphical User Interface elements and place them on the screen
		guiInit();

		// Initialize the screen with the current action item
		loadScreen();
	}

	/**
	 * Initialize each graphic element, position it on the screen, and add it to the loayout.
	 * 
	 */
	private void guiInit() {
		// Updating the GUI
		updatingGUI = true;
		
		// Set all of the graphical elements in this screen by adding them to the layout
		this.setLayout(null);

		actionItemLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 14));
		actionItemLabel.setBorder(BorderFactory.createEtchedBorder());
		actionItemLabel.setHorizontalAlignment(SwingConstants.CENTER);
		actionItemLabel.setText("Action Items");
		actionItemLabel.setBounds(new Rectangle(0, 0, 657, 20));

		selectedLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		selectedLabel.setText("Selected Action Item:");
		selectedLabel.setBounds(new Rectangle(6, 145, 123, 15));
		nameLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		nameLabel.setText("Name:");
		nameLabel.setBounds(new Rectangle(7, 165, 42, 15));
		nameTextField.setText("");
		nameTextField.setBounds(new Rectangle(46, 165, 390, 22));
		nameTextField.getDocument().addDocumentListener(aiChangeListener);

		//label action items
		ActionItemscb.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		ActionItemscb.setText("Action Items:");
		ActionItemscb.setBounds(new Rectangle(6, 20, 123, 15));
		
		
		//label select items
				selectaction.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
				selectaction.setText("Select an action item from the pull-down list above to examine and update it");
				selectaction.setBounds(new Rectangle(6, 70, 555, 15));
				
				//label sorting direction
				sortingdirection.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
				sortingdirection.setText("Sorting Direction:");
				sortingdirection.setBounds(new Rectangle(226, 89, 123, 15));
				
				inclusion.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
				inclusion.setText("Inclusion Factor");
				inclusion.setBounds(new Rectangle(70, 89, 123, 15));
				
				inclusioncb.setBounds(new Rectangle(70, 110, 130, 25));
				inclusioncb.addItem("Open Action Items");
				inclusioncb.addItem("Closed Action Items");
				inclusioncb.addItemListener(new ItemListener() {

					public void itemStateChanged(ItemEvent e) {
						
						JComboBox inclusioncb=(JComboBox)e.getSource();
						Object item=e.getItem();
						int select=inclusioncb.getSelectedIndex();
						if(e.getStateChange()==ItemEvent.SELECTED) {
						
							switch(select) {
							case 0:
								try {
									BufferedReader br=new BufferedReader(new FileReader(file));
									String st;
									try {alist.clear();
										while((st=br.readLine())!=null) {
											String a[]=st.split(",");
											for(int i=0;i<a.length;i++) {
											if(a[i].contains("Open")) {
											alist.add(a[0]);
											}
											}
										}
									} catch (IOException e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									}
								}
								catch (FileNotFoundException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
								actioncb.removeAllItems();
								String[] arr= (String[]) alist.toArray(new String[] {});
								Arrays.sort(arr,0,arr.length);
								for(int i=0;i<arr.length;i++) {
									actioncb.addItem(arr[i]);
								}
								break;
								
							case 1:
								try {
									BufferedReader br=new BufferedReader(new FileReader(file));
									String st;
									try {alist.clear();
										while((st=br.readLine())!=null) {
											String a[]=st.split(",");
											for(int i=0;i<a.length;i++) {
											if(a[i].contains("Closed")) {
											alist.add(a[0]);
											}
											}
										}
									} catch (IOException e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									}
								}
								catch (FileNotFoundException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
								actioncb.removeAllItems();
								String[] array= (String[]) alist.toArray(new String[] {});
								Arrays.sort(array,0,array.length);
								for(int i=0;i<array.length;i++) {
									actioncb.addItem(array[i]);
								}
								break;
							}
					}}
					
				});
				//label first sorting factor
				firstsf.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
				firstsf.setText("First Sorting Factor:");
				firstsf.setBounds(new Rectangle(356, 89, 240, 15));
				
				//label second sorting factor
				secondsf.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
				secondsf.setText("Second Sorting Factor:");
				secondsf.setBounds(new Rectangle(489, 89, 243, 15));
		
		descriptionLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		descriptionLabel.setText("Description:");
		descriptionLabel.setBounds(new Rectangle(6, 190, 69, 15));
		descriptionScrollPane.setBounds(new Rectangle(7, 210, 430, 75));
		descriptionScrollPane.getViewport().add(descriptionTextArea);
		descriptionTextArea.setText("");
		descriptionTextArea.getDocument().addDocumentListener(aiChangeListener);

		resolutionLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		resolutionLabel.setText("Resolution:");
		resolutionLabel.setBounds(new Rectangle(6, 295, 73, 15));
		resolutionScrollPane.setBounds(new Rectangle(7, 315, 430, 75));
		resolutionScrollPane.getViewport().add(resolutionTextArea);
		resolutionTextArea.setToolTipText("");
		resolutionTextArea.setText("");
		resolutionTextArea.getDocument().addDocumentListener(aiChangeListener);

		datesLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		datesLabel.setText("Dates");
		datesLabel.setBounds(new Rectangle(450, 155, 34, 16));

		creationLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		creationLabel.setText("Creation:");
		creationLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		creationLabel.setBounds(new Rectangle(469, 175, 51, 16));
		creationValueLabel.setText("");
		creationValueLabel.setBounds(new Rectangle(528, 175, 85, 16));

		dueDateLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		dueDateLabel.setText("Due:");
		dueDateLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		dueDateLabel.setBounds(new Rectangle(469, 195, 51, 16));
		dueDateTextField.setBounds(new Rectangle(524, 195, 90, 20));
		dueDateTextField.getDocument().addDocumentListener(aiChangeListener);
		formatLabel.setFont(new java.awt.Font("Dialog", Font.PLAIN, 10));
		formatLabel.setText("Use yyyy-mm-dd format");
		formatLabel.setBounds(new Rectangle(495, 218, 125, 11));

		actionItemLabel2.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		actionItemLabel2.setText("Action Item");
		actionItemLabel2.setBounds(new Rectangle(450, 228, 67, 15));

		statusLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		statusLabel.setText("Status:");
		statusLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		statusLabel.setBounds(new Rectangle(469, 245, 51, 16));
		statusComboBox.setBounds(new Rectangle(524, 245, 90, 25));
		statusComboBox.addActionListener(statusSelectorActionListner);

		assign.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		assign.setText("Assigned to Member:");
		assign.setHorizontalAlignment(SwingConstants.RIGHT);
		assign.setBounds(new Rectangle(425, 275, 150, 16));
		assigncb.setBounds(new Rectangle(469, 300, 150, 25));
		
		assignt.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		assignt.setText("Assigned to team:");
		assignt.setHorizontalAlignment(SwingConstants.RIGHT);
		assignt.setBounds(new Rectangle(415, 330, 150, 16));
		assigntcb.setBounds(new Rectangle(469, 355, 150, 25));
		
		//action items cbox
		actioncb.setBounds(new Rectangle(6, 40, 410, 25));
		actioncb.addItemListener(new ItemListener() {

			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				JComboBox actioncb=(JComboBox)e.getSource();
				Object item=e.getItem();
				if(e.getStateChange()==ItemEvent.SELECTED) {
				
					 Scanner sc = null;
					    try {
					      sc = new Scanner(file);

					      // Check if there is another line of input
					      while(sc.hasNextLine()){
					        String str = sc.nextLine();
					        String a[]=item.toString().split(" ");
					        String b="";
					        for(int i=0;i<a.length;i++) {
					        	if(a[i].contains(":")) {
					        		continue;
					        	}
					        	b=b+a[i];
					        }
					        if(str.contains(b)) {
					      Scanner linescanner=new Scanner(str);
					      String name=null,des=null,res=null,due=null,creation=null,status=null,assign=null,team=null;
					      linescanner.useDelimiter(",");
					      while(linescanner.hasNext()) {
					    	  name=linescanner.next();
					    	  des=linescanner.next();
					    	  res=linescanner.next();
					    	  due=linescanner.next();
					    	  creation=linescanner.next();
					    	  status=linescanner.next();
					    	  assign=linescanner.next();
					    	  team=linescanner.next();
					    	  nameTextField.setText(name); 
					    	  descriptionTextArea.setText(des);
					    	  resolutionTextArea.setText(res);
					    	  dueDateTextField.setText(due);
					    	  creationValueLabel.setText(creation);
					    	  statusComboBox.setSelectedItem(status);
					    	  assigncb.setSelectedItem(assign);
					    	  assigntcb.setSelectedItem(team);
					      }
					      linescanner.close();
					        }
					      
					      }
					    } catch (IOException  exp) {
					      // TODO Auto-generated catch block
					      exp.printStackTrace();
					    }finally{
					      if(sc != null)
					        sc.close();
					    }	  	
							
				}
				unsavedChangesLabel.setText("");
			}
			
		});
		
		//sorting direction cbox
		sortingdirectioncb.setBounds(new Rectangle(226, 110, 100, 25));
		
		sortingdirectioncb.addItem("Large to Small");
		sortingdirectioncb.addItem("Small to Large");
		sortingdirectioncb.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				JComboBox sortingdirectioncb=(JComboBox)e.getSource();
				Object item=e.getItem();
				
				int selection=sortingdirectioncb.getSelectedIndex();
				switch(selection) {
				case 0: lts();
					break;
				case 1: stl();
					break;
				}
			}
		});
		
		//first sorting factor cbox
				firstsfcb.setBounds(new Rectangle(356, 110, 110, 25));
				firstsfcb.addItem("None");
				firstsfcb.addItem("Creation Date");
				firstsfcb.addItem("Due Date");
				firstsfcb.addItem("Assigned Member");
				firstsfcb.addItem("Assigned Team");
				firstsfcb.addItemListener(new ItemListener() {
					public void itemStateChanged(ItemEvent e) {
						// TODO Auto-generated method stub
						int selection=firstsfcb.getSelectedIndex();
						JComboBox firstsfcb=(JComboBox)e.getSource();
						Object item=e.getItem();
						switch(selection) {
						case 0: 
							if(secondsfcb.getSelectedIndex()==0) {
							if(sortingdirectioncb.getSelectedIndex()==0) {
								lts();
							}
							else if(sortingdirectioncb.getSelectedIndex()==1) {
								stl();
							}
							}
							
							if(secondsfcb.getSelectedIndex()==1) {
								if(sortingdirectioncb.getSelectedIndex()==0) {
									duels();
								}
								else if(sortingdirectioncb.getSelectedIndex()==1) {
									duesl();
								}
								}
							
							if(secondsfcb.getSelectedIndex()==2) {
								if(sortingdirectioncb.getSelectedIndex()==0) {
									createls();
								}
								else if(sortingdirectioncb.getSelectedIndex()==1) {
									createsl();
								}
								}
							break;
						case 1: 
							if(secondsfcb.getSelectedIndex()==0) {
							if(sortingdirectioncb.getSelectedIndex()==0) {
								createls();
							}
							else if(sortingdirectioncb.getSelectedIndex()==1) {
								createsl();
							}
							}
							//problem was here
							if(secondsfcb.getSelectedIndex()==1) {
								if(sortingdirectioncb.getSelectedIndex()==0) {
									duecreatels();
								}
								else if(sortingdirectioncb.getSelectedIndex()==1) {
									duecreatesl();
								}
							}
							if(secondsfcb.getSelectedIndex()==3) {
								if(sortingdirectioncb.getSelectedIndex()==0) {
									assigncl();
								}
								else if(sortingdirectioncb.getSelectedIndex()==1) {
									assigncs();
								}
								}
							break;
							case 2:
								if(secondsfcb.getSelectedIndex()==0) {
									if(sortingdirectioncb.getSelectedIndex()==0) {
										duels();
									}
									else if(sortingdirectioncb.getSelectedIndex()==1) {
										duesl();
									}
									}
								if(secondsfcb.getSelectedIndex()==2) {
									if(sortingdirectioncb.getSelectedIndex()==0) {
										duecreatels();	
									}
									else if(sortingdirectioncb.getSelectedIndex()==1) {
										duecreatesl();
									}
									}
								if(secondsfcb.getSelectedIndex()==3) {
									if(sortingdirectioncb.getSelectedIndex()==0) {
										assigndl();
									}
									else if(sortingdirectioncb.getSelectedIndex()==1) {
										assignds();
									}
									}
								break;
								
								
							case 3:
								if(secondsfcb.getSelectedIndex()==0) {
									if(sortingdirectioncb.getSelectedIndex()==0) {
										assignls();
									}
									else if(sortingdirectioncb.getSelectedIndex()==1) {
										assignsl();
									}
									}
								
								if(secondsfcb.getSelectedIndex()==1) {
									if(sortingdirectioncb.getSelectedIndex()==0) {
										assigndl();
									}
									else if(sortingdirectioncb.getSelectedIndex()==1) {
										assignds();
									}
									}
								
								if(secondsfcb.getSelectedIndex()==2) {
									if(sortingdirectioncb.getSelectedIndex()==0) {
										assigncl();
									}
									else if(sortingdirectioncb.getSelectedIndex()==1) {
										assigncs();
									}
									}
								
								if(secondsfcb.getSelectedIndex()==4) {
									if(sortingdirectioncb.getSelectedIndex()==0) {
										assigntcdl();
									}
									else if(sortingdirectioncb.getSelectedIndex()==1) {
										assigntcds();
									}
									}
								break;
								
							case 4:
								if(secondsfcb.getSelectedIndex()==0) {
									if(sortingdirectioncb.getSelectedIndex()==0) {
										assigntls();
									}
									else if(sortingdirectioncb.getSelectedIndex()==1) {
										assigntsl();
									}
									}
								
								if(secondsfcb.getSelectedIndex()==1) {
									if(sortingdirectioncb.getSelectedIndex()==0) {
										assigntdl();
									}
									else if(sortingdirectioncb.getSelectedIndex()==1) {
										assigntds();
									}
									}
								
								if(secondsfcb.getSelectedIndex()==2) {
									if(sortingdirectioncb.getSelectedIndex()==0) {
										assigntcl();
									}
									else if(sortingdirectioncb.getSelectedIndex()==1) {
										assigntcs();
									}
									}
								if(secondsfcb.getSelectedIndex()==3) {
									if(sortingdirectioncb.getSelectedIndex()==0) {
										assigntcdl();
									}
									else if(sortingdirectioncb.getSelectedIndex()==1) {
										assigntcds();
									}
									}
								
								break;
							}
						}
				});	
				
				
		//second sorting factor cbox
		secondsfcb.setBounds(new Rectangle(489, 110, 110, 25));
		secondsfcb.addItem("None");
		secondsfcb.addItem("Due Date");
		secondsfcb.addItem("Creation Date");
		secondsfcb.addItem("Assigned Member");
		secondsfcb.addItem("Assigned Team");
		secondsfcb.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				int selection=secondsfcb.getSelectedIndex();
				JComboBox secondsfcb=(JComboBox)e.getSource();
				Object item=e.getItem();
				switch(selection) {
				case 0: 
					if(firstsfcb.getSelectedIndex()==0) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							lts();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							stl();
						}
						}
					if(firstsfcb.getSelectedIndex()==1) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							createls();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							createsl();
						}
						}
					if(firstsfcb.getSelectedIndex()==2) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							duels();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							duesl();
						}
						}
						break;
				case 1:
					if(firstsfcb.getSelectedIndex()==0) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							duels();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
						duesl();
						}
						}
					if(firstsfcb.getSelectedIndex()==1) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							duecreatels();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							duecreatesl();
						}
						}
					if(firstsfcb.getSelectedIndex()==3) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							assigndl();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							assignds();
						}
						}
					break;
				case 2:
					if(firstsfcb.getSelectedIndex()==0) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							createls();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							createsl();
						}
						}
					if(firstsfcb.getSelectedIndex()==2) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							duecreatels();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							duecreatesl();
						}
						}
					
					if(firstsfcb.getSelectedIndex()==3) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							assigncl();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							assigncs();
						}
						}
					break;
					
				case 3:
					if(firstsfcb.getSelectedIndex()==0) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							assignls();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							assignsl();
						}
						}
					if(firstsfcb.getSelectedIndex()==2) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							assigndl();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							assignds();
						}
						}
					
					if(firstsfcb.getSelectedIndex()==1) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							assigncl();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							assigncs();
						}
						}
					if(firstsfcb.getSelectedIndex()==4) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							assigntcdl();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							assigntcds();
						}
						}
					break;
					
				case 4:
					if(firstsfcb.getSelectedIndex()==0) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							assigntls();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							assigntsl();
						}
						}
					
					if(firstsfcb.getSelectedIndex()==1) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							assigntdl();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							assigntds();
						}
						}
					
					if(firstsfcb.getSelectedIndex()==2) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							assigntcl();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							assigntcs();
						}
						}
					if(firstsfcb.getSelectedIndex()==3) {
						if(sortingdirectioncb.getSelectedIndex()==0) {
							assigntcdl();
						}
						else if(sortingdirectioncb.getSelectedIndex()==1) {
							assigntcds();
						}
						}
					
					break;
				}
			}
		});
		
		updateButton.setFont(new Font("Dialog", Font.BOLD, 11));
		updateButton.setBounds(new Rectangle(3, 395, 170, 30));
		updateButton.setText("Update This Action Item");
		updateButton.addActionListener(updateButtonActionListner);

		//new action item button
		createnewactionitem.setFont(new Font("Dialog", Font.BOLD, 11));
		createnewactionitem.setBounds(new Rectangle(300, 395, 165, 30));
		createnewactionitem.setText("Create New Action Item");
		createnewactionitem.addActionListener(createnewitem);
		
		deleteactionitem.setFont(new Font("Dialog", Font.BOLD, 11));
		deleteactionitem.setBounds(new Rectangle(465, 395, 165, 30));
		deleteactionitem.setText("Delete This Action Item");
		deleteactionitem.addActionListener(delButtonActionListner);
		
		clearButton.setFont(new Font("Dialog", Font.BOLD, 11));
		clearButton.setBounds(new Rectangle(173, 395, 126, 30));
		clearButton.setText("Clear This Form");
		clearButton.addActionListener(clearButtonActionListner);

		unsavedChangesLabel.setFont(new Font("Dialog", Font.BOLD, 12));
		unsavedChangesLabel.setBounds(new Rectangle(250, 430, 200, 15));
		unsavedChangesLabel.setText("");
		unsavedChangesLabel.setForeground(Color.red);		
		
		//----------------------------------------------------------------------------
		// Add the objects to the layout
		this.add(actionItemLabel);
        this.add(inclusion);
		this.add(selectedLabel);
		this.add(deleteactionitem);
		this.add(nameLabel);
		this.add(nameTextField);
		this.add(descriptionLabel);
		this.add(descriptionScrollPane);
		this.add(resolutionLabel);
		this.add(resolutionScrollPane);

		this.add(datesLabel);
		this.add(creationLabel);
		this.add(creationValueLabel);
		this.add(dueDateLabel);
		this.add(dueDateTextField);
		this.add(formatLabel);
		this.add(actionItemLabel2);
		this.add(statusLabel);
		this.add(statusComboBox);
		this.add(assignt);
		this.add(assigntcb);
		this.add(updateButton);
		this.add(clearButton);

		this.add(ActionItemscb);
		this.add(actioncb);
		this.add(selectaction);
		this.add(inclusioncb);
		this.add(createnewactionitem);
		this.add(unsavedChangesLabel);
		this.add(sortingdirection);
		this.add(sortingdirectioncb);
		this.add(firstsf);
		this.add(firstsfcb);
		this.add(secondsfcb);
		this.add(secondsf);
		this.add(assign);
		this.add(assigncb);

		// Done updating the GUI
		updatingGUI = false;
	}

	/**
	 * Clear the current action item and the attribute related combo boxes
	 * 
	 */
	public void deleteai() {
//		try {
//			BufferedReader br=new BufferedReader(new FileReader(file));
//			String st;
//			try {al.clear();
//				while((st=br.readLine())!=null) {
//					BufferedWriter bw=new BufferedWriter(new FileWriter(file));
//					String a[]=st.split(" ");
//					 String b="";
//				        for(int i=0;i<a.length;i++) {
//				        	if(a[i].contains(":")) {
//				        		continue;
//				        	}
//				        	b=b+a[i];
//				        }
//				        if(st.contains(b)) {
//				        	al.remove(st);
//				        	actioncb.removeItem(st);
//				        }
//				    	al.add(st);
//          				bw.write(st);
//          				bw.write("\n");
//          				bw.close();
//				        }
//				
//			} catch (IOException e1) {
//				// TODO Auto-generated catch block
//				e1.printStackTrace();
//			}
//		}
//		catch (FileNotFoundException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
//		actioncb.removeAllItems();
//		String[] arr= (String[]) al.toArray(new String[] {});
//		Arrays.sort(arr,0,arr.length);
//		for(int i=0;i<arr.length;i++) {
//			actioncb.addItem(arr[i]);
//		}
	}
	public void lts() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		actioncb.removeAllItems();
		String[] ar= (String[]) al.toArray(new String[] {});
		Arrays.sort(ar,0,ar.length);
		for(int k=ar.length-1;k>=0;k--) {
			actioncb.addItem(ar[k]);
		}
	}
	
	public void stl() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		actioncb.removeAllItems();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=0;i<arr.length;i++) {
			actioncb.addItem(arr[i]);
		}
	}
	
	public  void duecreatesl() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[3]+": "+a[4]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		actioncb.removeAllItems();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=0;i<arr.length;i++) {
			actioncb.addItem(arr[i]);
		}
	}
	
	public void duecreatels() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[3]+": "+a[4]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		actioncb.removeAllItems();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=arr.length-1;i>=0;i--) {
			actioncb.addItem(arr[i]);
		}	
	}
	
	public void createls() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[4]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		actioncb.removeAllItems();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=arr.length-1;i>=0;i--) {
			actioncb.addItem(arr[i]);
		}	
	}
	
	public void createsl() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[4]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		actioncb.removeAllItems();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=0;i<arr.length;i++) {
			actioncb.addItem(arr[i]);
		}
	}
	
	public void duesl() {
	  try {
		BufferedReader br=new BufferedReader(new FileReader(file));
		String st;
		try {al.clear();
			while((st=br.readLine())!=null) {
				String a[]=st.split(",");
				al.add(a[3]+": "+a[0]);
			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	catch (FileNotFoundException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	actioncb.removeAllItems();
	String[] arr= (String[]) al.toArray(new String[] {});
	Arrays.sort(arr,0,arr.length);
	for(int i=0;i<arr.length;i++) {
		actioncb.addItem(arr[i]);
	}
	}
	
	public void assigntcds() {
		  try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[7]+": "+a[6]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		actioncb.removeAllItems();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=0;i<arr.length;i++) {
			actioncb.addItem(arr[i]);
		}
		}
	
	public void assignsl() {
		  try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[6]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		actioncb.removeAllItems();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=0;i<arr.length;i++) {
			actioncb.addItem(arr[i]);
		}
		}
	
	public void assigntsl() {
		  try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[7]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		actioncb.removeAllItems();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=0;i<arr.length;i++) {
			actioncb.addItem(arr[i]);
		}
		}
	
	public void duels() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[3]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		actioncb.removeAllItems();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=arr.length-1;i>=0;i--) {
			actioncb.addItem(arr[i]);
		}	
	}
	
	public void assigntcdl() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[7]+": "+a[6]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		actioncb.removeAllItems();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=arr.length-1;i>=0;i--) {
			actioncb.addItem(arr[i]);
		}	
	}
	
	public void assignls() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[6]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		actioncb.removeAllItems();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=arr.length-1;i>=0;i--) {
			actioncb.addItem(arr[i]);
		}	
	}
	public void assigntls() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[7]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		actioncb.removeAllItems();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=arr.length-1;i>=0;i--) {
			actioncb.addItem(arr[i]);
		}	
	}
	
	public void assigncl() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[6]+": "+a[4]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		actioncb.removeAllItems();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=arr.length-1;i>=0;i--) {
			actioncb.addItem(arr[i]);
		}	
	}
	public void assigntcl() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[7]+": "+a[4]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		actioncb.removeAllItems();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=arr.length-1;i>=0;i--) {
			actioncb.addItem(arr[i]);
		}	
	}
	
	public void assigndl() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[6]+": "+a[3]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		actioncb.removeAllItems();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=arr.length-1;i>=0;i--) {
			actioncb.addItem(arr[i]);
		}	
	}
	public void assigntdl() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[7]+": "+a[3]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		actioncb.removeAllItems();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=arr.length-1;i>=0;i--) {
			actioncb.addItem(arr[i]);
		}	
	}
	
	public void assigncs() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[6]+": "+a[3]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		actioncb.removeAllItems();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=arr.length-1;i>=0;i--) {
			actioncb.addItem(arr[i]);
		}
	}
	public void assigntcs() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[7]+": "+a[3]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		actioncb.removeAllItems();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=arr.length-1;i>=0;i--) {
			actioncb.addItem(arr[i]);
		}
	}
	
	public void assignds() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[6]+": "+a[3]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		actioncb.removeAllItems();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=0;i<arr.length;i++) {
			actioncb.addItem(arr[i]);
		}
	}
	
	public void assigntds() {
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[7]+": "+a[3]+": "+a[0]);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		actioncb.removeAllItems();
		String[] arr= (String[]) al.toArray(new String[] {});
		Arrays.sort(arr,0,arr.length);
		for(int i=0;i<arr.length;i++) {
			actioncb.addItem(arr[i]);
		}
	}
	
	private void clearAI() {
		updatingGUI = true;
		aiM.clearCurrentActionItem();
		nameTextField.setText("");
		descriptionTextArea.setText("");
		resolutionTextArea.setText("");
		creationValueLabel.setText(dateFormat.format(new Date()));
		dueDateTextField.setText("");
        actioncb.setSelectedItem(null);
		// Select the Open status
		statusComboBox.setSelectedIndex(ActionItemManager.statusOpen);
		updatingGUI = false;
	}
	
	 File file=new File("file.txt");
	 
	 //creating a new action item 
	 
  private void createnewitem(ActionEvent e) {
	 
		actioncb.addItem(nameTextField.getText().toString());
		actioncb.setSelectedItem(nameTextField.getText().toString());
		try {
			
			if(file.createNewFile()) {
				System.out.print("");
			}
			else {
			}
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
       try {
		 BufferedWriter writer=new BufferedWriter(new FileWriter(file,true));
		 String s=nameTextField.getText().toString()+","+descriptionTextArea.getText().toString()+","+
				 resolutionTextArea.getText().toString()+","+dueDateTextField.getText().toString()+","+
				 creationValueLabel.getText().toString()+","+statusComboBox.getSelectedItem()+","+assigncb.getSelectedItem()+","+assigntcb.getSelectedItem();
		 writer.write(s);
		   writer.write("\n");
	     writer.close();
     } 
       catch (IOException e1) {
	// TODO Auto-generated catch block
	e1.printStackTrace();
          }
		unsavedChangesLabel.setText("");
	}
	
	
	/**
	 * Process a "Clear This Form" button click request
	 * Clear out the current action item and inform the user if this results in unsaved changes
	 * 
	 * @param e ActionEvent
	 */
	private void clearActionItemForm(ActionEvent e) {
		// Reset the current Action Item Fields
		clearAI();
		
		theController.setDirtyFlag(true);
		checkForUnsavedUpdates();
	}

	/**
	 * Update the current action item in memory
	 * 
	 * @param e ActionEvent
	 */
	private void updateActionItem(ActionEvent e) {
		// Tell the ActionItemManager to save the update
		try {
			aiM.updateActionItem(nameTextField.getText(),
					descriptionTextArea.getText(),
					resolutionTextArea.getText(),
					statusComboBox.getSelectedItem().toString(),
					dueDateTextField.getText(),
					actioncb.getSelectedItem().toString());
		}
		catch (Exception ex) {
			JOptionPane.showMessageDialog(this, ex.getMessage(),
					"Error",
					JOptionPane.ERROR_MESSAGE);
			return;
		}
		
		// This code is just for Della00 to simulate the effect of the "create" button being pressed
		// remove this for Della01
	//	creationValueLabel.setText(dateFormat.format(new Date()));

		theController.setDirtyFlag(true);
		checkForUnsavedUpdates();
	}

	/**
	 * Fill the screen with the values of the current action item, if we have one, and display it.
	 */
	public void loadScreen() {
		updatingGUI = true;
		// Fetch the current action item.  If there isn't one, leave now
		ActionItem ai = aiM.getCurrentActionItem();
		if (ai == null) {
			clearAI();
			updatingGUI = true;
			statusComboBox.setSelectedIndex(ActionItemManager.statusOpen);
			creationValueLabel.setText("");
			dueDateTextField.setText("");
		}
		else {
			// Define the text fields
			updatingGUI = true;
			nameTextField.setText(ai.getActionItemName());
			descriptionTextArea.setText(ai.getDescription());
			descriptionTextArea.setCaretPosition(0);
			resolutionTextArea.setText(ai.getResolution());
			resolutionTextArea.setCaretPosition(0);
		}
		
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String st;
			try {al.clear();
				while((st=br.readLine())!=null) {
					String a[]=st.split(",");
					al.add(a[0]);
				}
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		actioncb.removeAllItems();
		
		String[] ar= (String[]) al.toArray(new String[] {});
		//Arrays.sort(ar,0,ar.length);
		for(int i=0;i<ar.length;i++) {
			actioncb.addItem(ar[i]);
			
		}
		
		File mfile=new File("Members.txt");
		try {
			BufferedReader br=new BufferedReader(new FileReader(mfile));
			String st;
			try {assignmember.clear();
				while((st=br.readLine())!=null) {
					
					assignmember.add(st);
				}
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		assigncb.removeAllItems();
		
		String[] arr= (String[]) assignmember.toArray(new String[] {});
		//Arrays.sort(ar,0,ar.length);
		for(int i=0;i<arr.length;i++) {
			assigncb.addItem(arr[i]);
			
		}
		
		File tfile=new File("Teams.txt");
		try {
			BufferedReader br=new BufferedReader(new FileReader(tfile));
			String st;
			try {assignteam.clear();
				while((st=br.readLine())!=null) {
					
					assignteam.add(st);
				}
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		assigntcb.removeAllItems();
		
		String[] array= (String[]) assignteam.toArray(new String[] {});
		//Arrays.sort(ar,0,ar.length);
		for(int i=0;i<array.length;i++) {
			assigntcb.addItem(array[i]);
			
		}
		
		
		// Define the status combobox value
		for (int i = 0; i < ActionItemManager.statusStrings.length; ++i)
			if (ai.getStatus().compareTo(ActionItemManager.statusStrings[i]) == 0) {
				statusComboBox.setSelectedIndex(i);
				break;
			}
	
		// Define the creation and due dates
		if (ai.getCreatedDate() != null)
			creationValueLabel.setText(dateFormat.format(ai.getCreatedDate()));
		else
			creationValueLabel.setText(dateFormat.format(new Date()));
		if (ai.getDueDate() != null)
			dueDateTextField.setText(dateFormat.format(ai.getDueDate()));
		else
			dueDateTextField.setText("");
		
		updatingGUI = false;
	}

	/**
	 * Any number of events has occurred that could change the display.  See if the current edit values still
	 * match the current action item.  If so, then no warning is needed.  If not, then given a warning (red
	 * text) that informs the user that there are edits to the action item that have not been saved.
	 * 
	 */
	private void checkForUnsavedUpdates(){
		if (updatingGUI) return;
		if (nameTextField.getText().equals(aiM.getCurrentActionItem().getActionItemName()) &&
				descriptionTextArea.getText().equals(aiM.getCurrentActionItem().getDescription()) &&
				resolutionTextArea.getText().equals(aiM.getCurrentActionItem().getResolution()) && 
				dueDateTextField.getText().equals(aiM.getCurrentActionItem().getDueDate()!=null?dateFormat.format(aiM.getCurrentActionItem().getDueDate()):"") &&
				(	(statusComboBox.getSelectedIndex() == 0 && aiM.getCurrentActionItem().getStatus().equals("")) ||
						(statusComboBox.getSelectedIndex() == 0 && aiM.getCurrentActionItem().getStatus().equals("Open")) ||
						(statusComboBox.getSelectedIndex() == 1 && aiM.getCurrentActionItem().getStatus().equals("Closed"))
		)//&&
//				(actioncb.getSelectedItem()!=null)
		){
			unsavedChangesLabel.setText("");
			aiM.setEditChangesPending(false);
		}
		else {
			unsavedChangesLabel.setText("There are unsaved changes!");
			aiM.setEditChangesPending(true);
		}	
	}
}
